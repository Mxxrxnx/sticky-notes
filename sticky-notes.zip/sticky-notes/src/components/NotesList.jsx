import React from 'react';
import NoteCard from './NoteCard';

const NotesList = ({ notes, onDeleteNote }) => {
  if (notes.length === 0) {
    return (
      <div className="notes-empty">
        <p>📝 No tienes notas todavía. ¡Créala ahora!</p>
      </div>
    );
  }

  return (
    <div className="notes-container">
      <h2>Mis Notas ({notes.length})</h2>
      <div className="notes-grid">
        {notes.map(note => (
          <NoteCard
            key={note.id}
            note={note}
            onDelete={onDeleteNote}
          />
        ))}
      </div>
    </div>
  );
};

export default NotesList;