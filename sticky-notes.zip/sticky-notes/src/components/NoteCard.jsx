import React from 'react';

const NoteCard = ({ note, onDelete }) => {
  const handleDelete = () => {
    if (window.confirm('¿Quieres borrar esta nota?')) {
      onDelete(note.id);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className={`note-card ${note.isImportant ? 'important' : ''}`}>
      <div className="note-header">
        <h3 className="note-title">
          {note.isImportant && '⭐ '}
          {note.title}
        </h3>
        <button 
          className="delete-btn"
          onClick={handleDelete}
          title="Eliminar nota"
        >
          ✖
        </button>
      </div>
      
      <div className="note-content">
        <p className="note-description">{note.description}</p>
      </div>
      
      <div className="note-footer">
        <small className="note-date">
          {formatDate(note.createdAt)}
        </small>
      </div>
    </div>
  );
};

export default NoteCard;