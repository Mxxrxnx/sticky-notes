import React, { useState } from 'react';

const NoteForm = ({ onAddNote }) => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    isImportant: false
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    if (errors[name] && value.trim()) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.description.trim()) {
      newErrors.description = 'La descripción es OBLIGATORIA';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      onAddNote(formData);
      setFormData({
        title: '',
        description: '',
        isImportant: false
      });
    }
  };

  return (
    <form className="note-form" onSubmit={handleSubmit}>
      <h2>Crear Nueva Nota</h2>
      
      <div className="form-group">
        <label htmlFor="title">Título (opcional):</label>
        <input
          type="text"
          id="title"
          name="title"
          value={formData.title}
          onChange={handleChange}
          placeholder="Ingresa el título"
        />
      </div>

      <div className="form-group">
        <label htmlFor="description">Descripción*:</label>
        <textarea
          id="description"
          name="description"
          value={formData.description}
          onChange={handleChange}
          placeholder="Ingresa la descripción de la nota"
          rows="4"
          className={errors.description ? 'error' : ''}
        />
        {errors.description && (
          <span className="error-message">{errors.description}</span>
        )}
      </div>

      <div className="form-group checkbox-group">
        <label>
          <input
            type="checkbox"
            name="isImportant"
            checked={formData.isImportant}
            onChange={handleChange}
          />
          Marcar como importante
        </label>
      </div>

      <button type="submit" className="submit-btn">
        ➕ Agregar Nota
      </button>
    </form>
  );
};

export default NoteForm;