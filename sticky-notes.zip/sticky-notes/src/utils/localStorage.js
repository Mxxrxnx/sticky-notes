const NOTES_KEY = 'sticky-notes';

export const getNotesFromStorage = () => {
  try {
    const notes = localStorage.getItem(NOTES_KEY);
    return notes ? JSON.parse(notes) : [];
  } catch (error) {
    console.error('Error al intentar cargar notas:', error);
    return [];
  }
};

export const saveNotesToStorage = (notes) => {
  try {
    localStorage.setItem(NOTES_KEY, JSON.stringify(notes));
  } catch (error) {
    console.error('Error al guardar notas:', error);
  }
};

export const generateId = () => {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
};