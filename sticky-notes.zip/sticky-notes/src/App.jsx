import React, { useState, useEffect } from 'react';
import NoteForm from './components/NoteForm';
import NotesList from './components/NotesList';
import { getNotesFromStorage, saveNotesToStorage, generateId } from './utils/localStorage.js';
import './styles/App.css';

function App() {
  const [notes, setNotes] = useState([]);

  useEffect(() => {
    const savedNotes = getNotesFromStorage();
    setNotes(savedNotes);
  }, []);

  useEffect(() => {
    saveNotesToStorage(notes);
  }, [notes]);

  const addNote = (noteData) => {
    const newNote = {
      id: generateId(),
      title: noteData.title || 'Sin título',
      description: noteData.description,
      isImportant: noteData.isImportant || false,
      createdAt: new Date().toISOString()
    };
    
    setNotes(prevNotes => [...prevNotes, newNote]);
  };

  const deleteNote = (noteId) => {
    setNotes(prevNotes => prevNotes.filter(note => note.id !== noteId));
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>📝 Mis Notas Adhesivas</h1>
      </header>
      
      <main className="app-main">
        <NoteForm onAddNote={addNote} />
        <NotesList notes={notes} onDeleteNote={deleteNote} />
      </main>
    </div>
  );
}

export default App;